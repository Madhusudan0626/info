'''
this is an encryption algorithm; please try to understand how it works and
modify it thus it works for integers as well.
'''

def encrypt(text, shift):
    result = ""
    
    # traverse text
    for i in range(len(text)):
        char = text[i]
        
        # Encrypt uppercase characters
        if (char.isupper()):
            result += chr(((ord(char)) + shift - 65) % 26 + 65)
            
        # Encrypt lowercase characters
        else:result += chr(((ord(char)) + shift - 32) % 96 + 32)
    return result

def decrypt(text,shift):
    result=""
    for i in range(len(text)):
        char=text[i]

        if(char.isupper()):
            result += chr(((ord(char)) - shift - 65) % 26 + 65)
        else:result += chr(((ord(char))- shift -32) % 96 + 32)
    return result
    pass

k=encrypt("madhusudan$#%12",3)
print('Encrypt message : ',k)
print('Decrypt message : ',decrypt(k,3))