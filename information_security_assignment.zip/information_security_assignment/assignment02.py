'''
this is an encryption algorithm and it takes input as encrypt('text',[17,20])
write a decryption algorithm. Use Extended Euclidean Algorithm
 for finding modular inverse. So you have to keep in mind wheather 
 modular inverse exists or not.
'''

    
def encrypt(text, key):
    
    #C = (a*P + b) % 26
    
    return ''.join([ chr((( key[0]*(ord(t) - ord('A')) + key[1] ) % 26)
                  + ord('A')) for t in text.upper().replace(' ', '') ])

def decrypt(text,key):
    g , x , y=moduloIn(key[0],26)

    if(g!=1):
        print('No modulo inverse found,decryption not possible..')
        return
    else:
        return ''.join([ chr((((x%26)*(ord(c) - ord('A') - key[1]))
                  % 26) + ord('A')) for c in text ])

def moduloIn(a,b):
    if(a==0):
        return b , 0 , 1
    gcd , x , y=moduloIn(b%a,a)
    x1=y-(b//a)*x
    y1=x

    return gcd , x1 , y1

print('Plain text : MADHU')
print('encrypted message : ',encrypt("MADHU",[7,8]))
print('decrypted message : ',decrypt(encrypt("MADHU",[7,8]),[7,8]))